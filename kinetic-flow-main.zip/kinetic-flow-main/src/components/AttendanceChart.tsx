import { motion } from "framer-motion";

const hours = ["6am", "7am", "8am", "9am", "10am", "11am", "12pm", "1pm", "2pm", "3pm", "4pm", "5pm", "6pm", "7pm", "8pm", "9pm"];
const values = [4, 12, 28, 35, 22, 18, 14, 8, 10, 15, 20, 32, 38, 42, 30, 16];
const maxVal = Math.max(...values);

export function AttendanceChart() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.1, ease: [0.4, 0, 0.2, 1] }}
      className="rounded-xl border border-border/50 bg-card p-5"
    >
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-foreground">Flujo del Día</h3>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <div className="h-2 w-2 rounded-full bg-primary" />
            <span className="text-[10px] text-muted-foreground">Hoy</span>
          </div>
        </div>
      </div>
      <div className="flex h-40 items-end gap-1.5">
        {values.map((val, i) => (
          <div key={i} className="group relative flex flex-1 flex-col items-center">
            <motion.div
              initial={{ height: 0 }}
              animate={{ height: `${(val / maxVal) * 100}%` }}
              transition={{ duration: 0.5, delay: 0.03 * i, ease: [0.4, 0, 0.2, 1] }}
              className="w-full rounded-t-sm bg-primary/20 transition-smooth group-hover:bg-primary/40"
            >
              <div
                className="absolute bottom-0 w-full rounded-t-sm bg-primary/60"
                style={{ height: `${(val / maxVal) * 60}%` }}
              />
            </motion.div>
            <span className="mt-2 text-[8px] text-muted-foreground/60">{hours[i]}</span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
