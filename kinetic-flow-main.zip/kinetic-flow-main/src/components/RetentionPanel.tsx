import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { AlertTriangle, Clock, MessageSquare } from "lucide-react";

interface AtRiskMember {
  name: string;
  lastVisit: string;
  daysAway: number;
  plan: string;
  avatar: string;
}

const mockAtRisk: AtRiskMember[] = [
  { name: "Carlos Méndez", lastVisit: "Hace 12 días", daysAway: 12, plan: "Premium", avatar: "CM" },
  { name: "Ana Rodríguez", lastVisit: "Hace 9 días", daysAway: 9, plan: "Básico", avatar: "AR" },
  { name: "Luis Torres", lastVisit: "Hace 8 días", daysAway: 8, plan: "Premium", avatar: "LT" },
  { name: "María García", lastVisit: "Hace 7 días", daysAway: 7, plan: "VIP", avatar: "MG" },
];

export function RetentionPanel() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.2, ease: [0.4, 0, 0.2, 1] }}
      className="rounded-xl border border-border/50 bg-card"
    >
      <div className="flex items-center justify-between border-b border-border/30 px-5 py-4">
        <div className="flex items-center gap-2.5">
          <AlertTriangle className="h-4 w-4 text-coral" />
          <h3 className="text-sm font-semibold text-foreground">En Riesgo de Abandono</h3>
        </div>
        <span className="rounded-full bg-coral/10 px-2.5 py-0.5 text-[10px] font-bold text-coral">
          {mockAtRisk.length} miembros
        </span>
      </div>
      <div className="divide-y divide-border/20">
        {mockAtRisk.map((member, i) => (
          <motion.div
            key={member.name}
            initial={{ opacity: 0, x: -12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.1 * i, ease: [0.4, 0, 0.2, 1] }}
            className="flex items-center justify-between px-5 py-3.5 transition-smooth hover:bg-secondary/30"
          >
            <div className="flex items-center gap-3">
              <div className={cn(
                "flex h-9 w-9 items-center justify-center rounded-full text-xs font-bold",
                member.daysAway > 10 ? "bg-coral/15 text-coral" : "bg-primary/10 text-primary"
              )}>
                {member.avatar}
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">{member.name}</p>
                <div className="flex items-center gap-2">
                  <Clock className="h-3 w-3 text-muted-foreground/60" />
                  <span className="text-[11px] text-muted-foreground">{member.lastVisit}</span>
                  <span className="rounded bg-secondary px-1.5 py-0.5 text-[9px] font-medium text-muted-foreground">{member.plan}</span>
                </div>
              </div>
            </div>
            <button className="flex items-center gap-1.5 rounded-lg bg-primary/10 px-3 py-1.5 text-[11px] font-semibold text-primary transition-smooth hover:bg-primary/20">
              <MessageSquare className="h-3 w-3" />
              Reenganche
            </button>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
