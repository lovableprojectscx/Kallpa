import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface RecentCheckin {
  name: string;
  time: string;
  avatar: string;
  status: "active" | "expired" | "frozen";
}

const mockCheckins: RecentCheckin[] = [
  { name: "Roberto Silva", time: "08:15", avatar: "RS", status: "active" },
  { name: "Diana López", time: "08:12", avatar: "DL", status: "active" },
  { name: "Fernando Ruiz", time: "08:08", avatar: "FR", status: "active" },
  { name: "Patricia Vega", time: "08:02", avatar: "PV", status: "expired" },
  { name: "Andrés Mora", time: "07:55", avatar: "AM", status: "active" },
  { name: "Valeria Cruz", time: "07:48", avatar: "VC", status: "frozen" },
];

const statusLabels: Record<string, { label: string; className: string }> = {
  active: { label: "Activo", className: "bg-primary/10 text-primary" },
  expired: { label: "Vencido", className: "bg-coral/10 text-coral" },
  frozen: { label: "Congelado", className: "bg-secondary text-muted-foreground" },
};

export function RecentActivity() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.15, ease: [0.4, 0, 0.2, 1] }}
      className="rounded-xl border border-border/50 bg-card"
    >
      <div className="flex items-center justify-between border-b border-border/30 px-5 py-4">
        <h3 className="text-sm font-semibold text-foreground">Check-ins Recientes</h3>
        <span className="text-[11px] text-muted-foreground">Hoy</span>
      </div>
      <div className="divide-y divide-border/20">
        {mockCheckins.map((checkin, i) => {
          const status = statusLabels[checkin.status];
          return (
            <motion.div
              key={checkin.name}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.05 * i }}
              className="flex items-center justify-between px-5 py-3 transition-smooth hover:bg-secondary/20"
            >
              <div className="flex items-center gap-3">
                <div className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-full text-[10px] font-bold",
                  checkin.status === "active" ? "bg-primary/10 text-primary" : 
                  checkin.status === "expired" ? "bg-coral/15 text-coral" : "bg-secondary text-muted-foreground"
                )}>
                  {checkin.avatar}
                </div>
                <span className="text-sm font-medium text-foreground">{checkin.name}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-semibold", status.className)}>
                  {status.label}
                </span>
                <span className="font-mono text-xs text-muted-foreground">{checkin.time}</span>
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
