import { Layout } from "@/components/Layout";
import { StatCard } from "@/components/StatCard";
import { RetentionPanel } from "@/components/RetentionPanel";
import { RecentActivity } from "@/components/RecentActivity";
import { AttendanceChart } from "@/components/AttendanceChart";
import { Users, UserCheck, TrendingUp, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

const Index = () => {
  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <h1 className="font-display text-2xl text-foreground">Dashboard</h1>
          <p className="text-sm text-muted-foreground">Resumen operativo · Lunes, 24 Feb 2026</p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Miembros Activos"
            value="347"
            change="+12"
            changeType="positive"
            icon={Users}
            subtitle="de 380 registrados"
          />
          <StatCard
            title="Check-ins Hoy"
            value="89"
            change="+15%"
            changeType="positive"
            icon={UserCheck}
          />
          <StatCard
            title="Ingresos del Mes"
            value="$48.2K"
            change="+8%"
            changeType="positive"
            icon={TrendingUp}
          />
          <StatCard
            title="Vencimientos"
            value="14"
            change="esta semana"
            changeType="negative"
            icon={AlertCircle}
          />
        </div>

        {/* Charts + Activity */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
          <div className="lg:col-span-3">
            <AttendanceChart />
          </div>
          <div className="lg:col-span-2">
            <RecentActivity />
          </div>
        </div>

        {/* Retention */}
        <RetentionPanel />
      </div>
    </Layout>
  );
};

export default Index;
