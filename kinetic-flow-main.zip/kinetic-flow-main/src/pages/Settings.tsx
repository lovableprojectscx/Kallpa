import { Layout } from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { Building2, Globe, Bell, Shield, Copy, Gift } from "lucide-react";
import { useState } from "react";

const Settings = () => {
  const [referralCode] = useState("GYM-AF-8X2K9");

  return (
    <Layout>
      <div className="space-y-6 max-w-3xl">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
          <h1 className="font-display text-2xl text-foreground">Ajustes</h1>
          <p className="text-sm text-muted-foreground">Configuración general de tu gimnasio</p>
        </motion.div>

        {/* Gym Info */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-primary" />
              <CardTitle className="text-base">Información del Gimnasio</CardTitle>
            </div>
            <CardDescription>Datos públicos de tu negocio</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="gym-name">Nombre</Label>
                <Input id="gym-name" defaultValue="Iron Temple Gym" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gym-phone">Teléfono</Label>
                <Input id="gym-phone" defaultValue="+52 555 123 4567" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="gym-address">Dirección</Label>
              <Input id="gym-address" defaultValue="Av. Insurgentes Sur 1234, CDMX" />
            </div>
            <Button size="sm">Guardar cambios</Button>
          </CardContent>
        </Card>

        {/* License */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-primary" />
              <CardTitle className="text-base">Licencia</CardTitle>
            </div>
            <CardDescription>Estado de tu licencia de GymFlow</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-lg border border-border/50 bg-secondary/30 p-4">
              <div>
                <p className="text-sm font-medium text-foreground">Plan Activo</p>
                <p className="text-xs text-muted-foreground">Válido hasta 24 Mar 2027</p>
              </div>
              <Badge className="bg-success/20 text-success border-success/30">Activa</Badge>
            </div>
            <div className="space-y-2">
              <Label htmlFor="license-code">Activar nueva licencia</Label>
              <div className="flex gap-2">
                <Input id="license-code" placeholder="XXXX-XXXX-XXXX" className="font-mono" />
                <Button size="sm">Activar</Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Affiliate */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Gift className="h-4 w-4 text-primary" />
              <CardTitle className="text-base">Programa de Afiliados</CardTitle>
            </div>
            <CardDescription>Invita a otros gimnasios y gana créditos por cada licencia activada</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3 rounded-lg border border-primary/20 bg-primary/5 p-4">
              <div className="flex-1">
                <p className="text-xs text-muted-foreground mb-1">Tu código de referido</p>
                <p className="font-mono text-sm font-bold text-primary">{referralCode}</p>
              </div>
              <Button variant="outline" size="sm" className="gap-1.5">
                <Copy className="h-3.5 w-3.5" />
                Copiar
              </Button>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-lg border border-border/50 bg-secondary/30 p-3 text-center">
                <p className="stat-number text-lg text-foreground">5</p>
                <p className="text-[10px] text-muted-foreground">Invitados</p>
              </div>
              <div className="rounded-lg border border-border/50 bg-secondary/30 p-3 text-center">
                <p className="stat-number text-lg text-primary">3</p>
                <p className="text-[10px] text-muted-foreground">Activados</p>
              </div>
              <div className="rounded-lg border border-border/50 bg-secondary/30 p-3 text-center">
                <p className="stat-number text-lg text-success">$150</p>
                <p className="text-[10px] text-muted-foreground">Créditos</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Bell className="h-4 w-4 text-primary" />
              <CardTitle className="text-base">Notificaciones</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { label: "Alertas de vencimiento", desc: "Notificar 3 días antes de expirar membresías", default: true },
              { label: "Check-ins diarios", desc: "Resumen al final del día", default: false },
              { label: "Miembros en riesgo", desc: "Alerta cuando un miembro no asiste en 7 días", default: true },
            ].map((item) => (
              <div key={item.label} className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-foreground">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
                <Switch defaultChecked={item.default} />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Branding */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Globe className="h-4 w-4 text-primary" />
              <CardTitle className="text-base">Personalización</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Logo del gimnasio</Label>
              <div className="flex h-24 w-24 items-center justify-center rounded-lg border border-dashed border-border bg-secondary/30 text-xs text-muted-foreground cursor-pointer hover:border-primary/50 transition-smooth">
                Subir
              </div>
            </div>
            <div className="space-y-2">
              <Label>Zona horaria</Label>
              <Input defaultValue="America/Mexico_City" />
            </div>
            <Button size="sm">Guardar</Button>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Settings;
