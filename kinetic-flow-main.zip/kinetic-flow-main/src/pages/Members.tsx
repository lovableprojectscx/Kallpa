import { Layout } from "@/components/Layout";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Search, Filter, MoreHorizontal, Star } from "lucide-react";

interface Member {
  name: string;
  avatar: string;
  plan: string;
  status: "active" | "expired" | "frozen";
  lastVisit: string;
  streak: number;
  isVip: boolean;
  badge?: string;
}

const members: Member[] = [
  { name: "Roberto Silva", avatar: "RS", plan: "Premium", status: "active", lastVisit: "Hoy", streak: 24, isVip: true, badge: "Mañanero" },
  { name: "Diana López", avatar: "DL", plan: "Premium", status: "active", lastVisit: "Hoy", streak: 18, isVip: false, badge: "Constante" },
  { name: "Fernando Ruiz", avatar: "FR", plan: "VIP", status: "active", lastVisit: "Ayer", streak: 45, isVip: true },
  { name: "Patricia Vega", avatar: "PV", plan: "Básico", status: "expired", lastVisit: "Hace 3 días", streak: 0, isVip: false },
  { name: "Andrés Mora", avatar: "AM", plan: "Premium", status: "active", lastVisit: "Hoy", streak: 12, isVip: false, badge: "Nocturno" },
  { name: "Valeria Cruz", avatar: "VC", plan: "Básico", status: "frozen", lastVisit: "Hace 15 días", streak: 0, isVip: false },
  { name: "Carlos Méndez", avatar: "CM", plan: "Premium", status: "active", lastVisit: "Hace 12 días", streak: 3, isVip: false },
  { name: "Ana Rodríguez", avatar: "AR", plan: "Básico", status: "active", lastVisit: "Hace 9 días", streak: 5, isVip: false },
];

const statusMap: Record<string, { label: string; className: string }> = {
  active: { label: "Activo", className: "bg-primary/10 text-primary" },
  expired: { label: "Vencido", className: "bg-coral/10 text-coral" },
  frozen: { label: "Congelado", className: "bg-secondary text-muted-foreground" },
};

const Members = () => {
  return (
    <Layout>
      <div className="space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-2xl text-foreground">Miembros</h1>
            <p className="text-sm text-muted-foreground">{members.length} registrados</p>
          </div>
          <button className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-smooth hover:opacity-90">
            + Nuevo Miembro
          </button>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground/60" />
            <input
              type="text"
              placeholder="Buscar por nombre..."
              className="h-9 w-full rounded-lg border border-border/50 bg-card pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/30"
            />
          </div>
          <button className="flex h-9 items-center gap-2 rounded-lg border border-border/50 bg-card px-3 text-xs text-muted-foreground transition-smooth hover:border-border hover:text-foreground">
            <Filter className="h-3.5 w-3.5" />
            Filtros
          </button>
        </div>

        {/* Table */}
        <div className="overflow-hidden rounded-xl border border-border/50 bg-card">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border/30">
                <th className="px-5 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/60">Miembro</th>
                <th className="px-5 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/60">Plan</th>
                <th className="px-5 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/60">Estado</th>
                <th className="px-5 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/60">Última Visita</th>
                <th className="px-5 py-3 text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/60">Racha</th>
                <th className="px-5 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border/15">
              {members.map((member, i) => {
                const st = statusMap[member.status];
                return (
                  <motion.tr
                    key={member.name}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.2, delay: 0.03 * i }}
                    className="transition-smooth hover:bg-secondary/20 cursor-pointer"
                  >
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          "flex h-9 w-9 items-center justify-center rounded-full text-xs font-bold",
                          member.isVip ? "bg-primary/15 text-primary" : "bg-secondary text-muted-foreground"
                        )}>
                          {member.avatar}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-foreground">{member.name}</span>
                            {member.isVip && <Star className="h-3 w-3 fill-primary text-primary" />}
                          </div>
                          {member.badge && (
                            <span className="inline-block rounded bg-primary/8 px-1.5 py-0.5 text-[9px] font-medium text-primary/80 mt-0.5">
                              {member.badge}
                            </span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-sm text-foreground">{member.plan}</td>
                    <td className="px-5 py-3.5">
                      <span className={cn("rounded-full px-2.5 py-1 text-[10px] font-semibold", st.className)}>
                        {st.label}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-sm text-muted-foreground">{member.lastVisit}</td>
                    <td className="px-5 py-3.5">
                      {member.streak > 0 ? (
                        <div className="flex items-center gap-1.5">
                          <span className="stat-number text-sm text-foreground">{member.streak}</span>
                          <span className="text-[10px] text-muted-foreground">días</span>
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground/40">—</span>
                      )}
                    </td>
                    <td className="px-5 py-3.5">
                      <button className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground transition-smooth hover:bg-secondary hover:text-foreground">
                        <MoreHorizontal className="h-4 w-4" />
                      </button>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  );
};

export default Members;
