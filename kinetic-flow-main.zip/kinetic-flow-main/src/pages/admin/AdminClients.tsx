import { AdminLayout } from "@/components/AdminLayout";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { motion } from "framer-motion";
import { Search } from "lucide-react";
import { useState } from "react";

const mockClients = [
  { name: "Iron Temple Gym", email: "admin@irontemple.com", license: "GF-2026-A1B2", status: "active", since: "20 Ene 2026", referredBy: "Carlos Méndez" },
  { name: "PowerHouse CDMX", email: "info@powerhouse.mx", license: "GF-2026-C3D4", status: "active", since: "22 Feb 2026", referredBy: null },
  { name: "FitZone Norte", email: "hola@fitzone.com", license: "GF-2025-X9Y0", status: "expired", since: "05 Jun 2025", referredBy: "Ana Ríos" },
];

const AdminClients = () => {
  const [search, setSearch] = useState("");
  const filtered = mockClients.filter((c) =>
    c.name.toLowerCase().includes(search.toLowerCase()) || c.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AdminLayout>
      <div className="space-y-6">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <h1 className="font-display text-2xl text-foreground">Clientes</h1>
          <p className="text-sm text-muted-foreground">Gimnasios que han activado una licencia</p>
        </motion.div>

        <Card>
          <CardHeader className="pb-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground/60" />
              <Input placeholder="Buscar cliente..." className="pl-9 h-8 text-xs" value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-[10px] uppercase">Gimnasio</TableHead>
                  <TableHead className="text-[10px] uppercase">Email</TableHead>
                  <TableHead className="text-[10px] uppercase">Licencia</TableHead>
                  <TableHead className="text-[10px] uppercase">Estado</TableHead>
                  <TableHead className="text-[10px] uppercase">Desde</TableHead>
                  <TableHead className="text-[10px] uppercase">Referido por</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((c) => (
                  <TableRow key={c.email}>
                    <TableCell className="text-xs font-medium">{c.name}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{c.email}</TableCell>
                    <TableCell className="font-mono text-xs">{c.license}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={c.status === "active" ? "bg-success/15 text-success border-success/30" : "bg-coral/15 text-coral border-coral/30"}>
                        {c.status === "active" ? "Activo" : "Expirado"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">{c.since}</TableCell>
                    <TableCell className="text-xs">{c.referredBy || "—"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default AdminClients;
