import { AdminLayout } from "@/components/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion } from "framer-motion";
import { Plus, Search, Copy } from "lucide-react";
import { useState } from "react";

interface License {
  code: string;
  duration: string;
  status: "available" | "redeemed" | "expired";
  createdAt: string;
  redeemedBy: string | null;
  redeemedAt: string | null;
}

const mockLicenses: License[] = [
  { code: "GF-2026-A1B2", duration: "12 meses", status: "redeemed", createdAt: "15 Ene 2026", redeemedBy: "Iron Temple Gym", redeemedAt: "20 Ene 2026" },
  { code: "GF-2026-C3D4", duration: "6 meses", status: "redeemed", createdAt: "18 Ene 2026", redeemedBy: "PowerHouse CDMX", redeemedAt: "22 Feb 2026" },
  { code: "GF-2026-E5F6", duration: "12 meses", status: "available", createdAt: "20 Feb 2026", redeemedBy: null, redeemedAt: null },
  { code: "GF-2026-G7H8", duration: "3 meses", status: "available", createdAt: "21 Feb 2026", redeemedBy: null, redeemedAt: null },
  { code: "GF-2025-X9Y0", duration: "6 meses", status: "expired", createdAt: "01 Jun 2025", redeemedBy: "FitZone Norte", redeemedAt: "05 Jun 2025" },
];

const statusConfig = {
  available: { label: "Disponible", className: "bg-primary/15 text-primary border-primary/30" },
  redeemed: { label: "Canjeada", className: "bg-success/15 text-success border-success/30" },
  expired: { label: "Expirada", className: "bg-coral/15 text-coral border-coral/30" },
};

const AdminLicenses = () => {
  const [search, setSearch] = useState("");

  const filtered = mockLicenses.filter(
    (l) =>
      l.code.toLowerCase().includes(search.toLowerCase()) ||
      (l.redeemedBy && l.redeemedBy.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <AdminLayout>
      <div className="space-y-6">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-2xl text-foreground">Licencias</h1>
            <p className="text-sm text-muted-foreground">Crea y gestiona códigos de licencia</p>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1.5">
                <Plus className="h-3.5 w-3.5" />
                Nueva Licencia
              </Button>
            </DialogTrigger>
            <DialogContent className="glass border-border/50">
              <DialogHeader>
                <DialogTitle>Crear Licencia</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-2">
                <div className="space-y-2">
                  <Label>Duración</Label>
                  <Select defaultValue="12">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 mes</SelectItem>
                      <SelectItem value="3">3 meses</SelectItem>
                      <SelectItem value="6">6 meses</SelectItem>
                      <SelectItem value="12">12 meses</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Cantidad</Label>
                  <Input type="number" defaultValue="1" min="1" max="50" />
                </div>
                <Button className="w-full">Generar Código(s)</Button>
              </div>
            </DialogContent>
          </Dialog>
        </motion.div>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground/60" />
                <Input
                  placeholder="Buscar por código o cliente..."
                  className="pl-9 h-8 text-xs"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-[10px] uppercase">Código</TableHead>
                  <TableHead className="text-[10px] uppercase">Duración</TableHead>
                  <TableHead className="text-[10px] uppercase">Estado</TableHead>
                  <TableHead className="text-[10px] uppercase">Creada</TableHead>
                  <TableHead className="text-[10px] uppercase">Canjeado por</TableHead>
                  <TableHead className="text-[10px] uppercase">Fecha Canje</TableHead>
                  <TableHead className="text-[10px] uppercase w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((l) => {
                  const st = statusConfig[l.status];
                  return (
                    <TableRow key={l.code}>
                      <TableCell className="font-mono text-xs font-medium">{l.code}</TableCell>
                      <TableCell className="text-xs">{l.duration}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={st.className}>{st.label}</Badge>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">{l.createdAt}</TableCell>
                      <TableCell className="text-xs">{l.redeemedBy || "—"}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{l.redeemedAt || "—"}</TableCell>
                      <TableCell>
                        {l.status === "available" && (
                          <Button variant="ghost" size="icon" className="h-7 w-7">
                            <Copy className="h-3 w-3" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default AdminLicenses;
