import { AdminLayout } from "@/components/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { Gift, TrendingUp, Users } from "lucide-react";

const mockAffiliates = [
  { name: "Carlos Méndez", code: "GYM-AF-CM01", invites: 12, activated: 9, credits: 450, topClient: "Iron Temple Gym" },
  { name: "Ana Ríos", code: "GYM-AF-AR02", invites: 8, activated: 5, credits: 250, topClient: "FitZone Norte" },
  { name: "Diego Vargas", code: "GYM-AF-DV03", invites: 15, activated: 3, credits: 150, topClient: "Muscle Factory" },
  { name: "Laura Peña", code: "GYM-AF-LP04", invites: 4, activated: 4, credits: 200, topClient: "CrossBox Sur" },
];

const AdminAffiliates = () => {
  const totalCredits = mockAffiliates.reduce((sum, a) => sum + a.credits, 0);
  const totalActivated = mockAffiliates.reduce((sum, a) => sum + a.activated, 0);

  return (
    <AdminLayout>
      <div className="space-y-6">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <h1 className="font-display text-2xl text-foreground">Afiliados</h1>
          <p className="text-sm text-muted-foreground">Seguimiento del programa de referidos</p>
        </motion.div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <Card>
            <CardContent className="flex items-center gap-4 p-5">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Users className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="stat-number text-xl text-foreground">{mockAffiliates.length}</p>
                <p className="text-[11px] text-muted-foreground">Afiliados activos</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-5">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                <Gift className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="stat-number text-xl text-foreground">{totalActivated}</p>
                <p className="text-[11px] text-muted-foreground">Licencias por referido</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-5">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <TrendingUp className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="stat-number text-xl text-primary">${totalCredits}</p>
                <p className="text-[11px] text-muted-foreground">Créditos totales</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Tabla de Afiliados</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-[10px] uppercase">Afiliado</TableHead>
                  <TableHead className="text-[10px] uppercase">Código</TableHead>
                  <TableHead className="text-[10px] uppercase">Invitados</TableHead>
                  <TableHead className="text-[10px] uppercase">Activados</TableHead>
                  <TableHead className="text-[10px] uppercase">Créditos</TableHead>
                  <TableHead className="text-[10px] uppercase">Mejor Cliente</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockAffiliates.map((a) => (
                  <TableRow key={a.code}>
                    <TableCell className="text-xs font-medium">{a.name}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{a.code}</TableCell>
                    <TableCell className="text-xs">{a.invites}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-success/15 text-success border-success/30">{a.activated}</Badge>
                    </TableCell>
                    <TableCell className="text-xs font-medium text-primary">${a.credits}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{a.topClient}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default AdminAffiliates;
