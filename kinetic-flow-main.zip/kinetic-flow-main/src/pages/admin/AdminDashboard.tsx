import { AdminLayout } from "@/components/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";
import { KeyRound, Users, Gift, DollarSign } from "lucide-react";

const stats = [
  { title: "Licencias Creadas", value: "128", icon: KeyRound, color: "text-primary" },
  { title: "Licencias Activas", value: "94", icon: KeyRound, color: "text-success" },
  { title: "Clientes", value: "94", icon: Users, color: "text-foreground" },
  { title: "Créditos Afiliados", value: "$2,340", icon: DollarSign, color: "text-primary" },
];

const AdminDashboard = () => {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <h1 className="font-display text-2xl text-foreground">Panel Admin</h1>
          <p className="text-sm text-muted-foreground">Gestión de licencias y afiliados de GymFlow</p>
        </motion.div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((s) => (
            <Card key={s.title}>
              <CardContent className="flex items-center gap-4 p-5">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                  <s.icon className={`h-5 w-5 ${s.color}`} />
                </div>
                <div>
                  <p className="stat-number text-xl text-foreground">{s.value}</p>
                  <p className="text-[11px] text-muted-foreground">{s.title}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Últimas Licencias Canjeadas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { code: "GF-2026-A1B2", client: "Iron Temple Gym", date: "23 Feb 2026" },
                { code: "GF-2026-C3D4", client: "PowerHouse CDMX", date: "22 Feb 2026" },
                { code: "GF-2026-E5F6", client: "FitZone Norte", date: "20 Feb 2026" },
              ].map((l) => (
                <div key={l.code} className="flex items-center justify-between rounded-lg bg-secondary/30 px-3 py-2.5">
                  <div>
                    <p className="font-mono text-xs font-medium text-foreground">{l.code}</p>
                    <p className="text-[10px] text-muted-foreground">{l.client}</p>
                  </div>
                  <span className="text-[10px] text-muted-foreground">{l.date}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Top Afiliados</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { name: "Carlos Méndez", referrals: 12, credits: "$600" },
                { name: "Ana Ríos", referrals: 8, credits: "$400" },
                { name: "Diego Vargas", referrals: 5, credits: "$250" },
              ].map((a) => (
                <div key={a.name} className="flex items-center justify-between rounded-lg bg-secondary/30 px-3 py-2.5">
                  <div>
                    <p className="text-xs font-medium text-foreground">{a.name}</p>
                    <p className="text-[10px] text-muted-foreground">{a.referrals} referidos · {a.credits} créditos</p>
                  </div>
                  <Gift className="h-3.5 w-3.5 text-primary" />
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboard;
