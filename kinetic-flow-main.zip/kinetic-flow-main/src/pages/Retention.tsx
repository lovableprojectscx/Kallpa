import { Layout } from "@/components/Layout";
import { RetentionPanel } from "@/components/RetentionPanel";
import { motion } from "framer-motion";
import { TrendingDown, UserMinus, RefreshCw, Target } from "lucide-react";
import { StatCard } from "@/components/StatCard";

const Retention = () => {
  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="font-display text-2xl text-foreground">Central de Retención</h1>
          <p className="text-sm text-muted-foreground">Monitorea y recupera miembros en riesgo</p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard title="Tasa de Retención" value="92%" change="+2%" changeType="positive" icon={Target} />
          <StatCard title="En Riesgo" value="4" change="7+ días sin visita" changeType="negative" icon={TrendingDown} />
          <StatCard title="Bajas este Mes" value="3" change="-1" changeType="positive" icon={UserMinus} />
          <StatCard title="Reenganchados" value="7" change="este mes" changeType="positive" icon={RefreshCw} />
        </div>

        <RetentionPanel />

        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          className="rounded-xl border border-border/50 bg-card p-5"
        >
          <h3 className="text-sm font-semibold text-foreground mb-3">Acciones de Reenganche</h3>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
            {[
              { title: "WhatsApp Automático", desc: "Enviar mensaje personalizado tras 5 días de inactividad", active: true },
              { title: "Pase de Invitado", desc: "Ofrecer un pase gratuito para acompañante como incentivo", active: true },
              { title: "Descuento de Recuperación", desc: "10% de descuento si renueva dentro de las próximas 48h", active: false },
            ].map((action) => (
              <div key={action.title} className="rounded-lg border border-border/30 bg-secondary/20 p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">{action.title}</span>
                  <div className={`h-2 w-2 rounded-full ${action.active ? 'bg-primary' : 'bg-muted-foreground/30'}`} />
                </div>
                <p className="text-xs text-muted-foreground">{action.desc}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </Layout>
  );
};

export default Retention;
