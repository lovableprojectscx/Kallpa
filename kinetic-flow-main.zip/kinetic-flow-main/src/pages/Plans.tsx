import { Layout } from "@/components/Layout";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Check, Snowflake, Users } from "lucide-react";

interface Plan {
  name: string;
  price: string;
  period: string;
  features: string[];
  members: number;
  popular: boolean;
  color: "volt" | "default" | "coral";
}

const plans: Plan[] = [
  {
    name: "Básico",
    price: "$29",
    period: "/mes",
    features: ["Acceso a sala de pesas", "Horario estándar (6am-10pm)", "Casillero compartido"],
    members: 120,
    popular: false,
    color: "default",
  },
  {
    name: "Premium",
    price: "$59",
    period: "/mes",
    features: ["Acceso total 24/7", "Clases grupales incluidas", "Casillero personal", "1 congelamiento/año", "App con rutinas"],
    members: 185,
    popular: true,
    color: "volt",
  },
  {
    name: "VIP",
    price: "$99",
    period: "/mes",
    features: ["Todo en Premium", "Entrenador personal 2x/sem", "Nutrición personalizada", "Acceso a spa", "3 pases de invitado/mes", "Congelamiento ilimitado"],
    members: 42,
    popular: false,
    color: "default",
  },
];

const Plans = () => {
  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="font-display text-2xl text-foreground">Planes</h1>
          <p className="text-sm text-muted-foreground">Configura y gestiona tus membresías</p>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.1 * i, ease: [0.4, 0, 0.2, 1] }}
              className={cn(
                "relative rounded-xl border bg-card p-6 transition-smooth",
                plan.popular
                  ? "border-primary/30 glow-volt"
                  : "border-border/50 hover:border-border"
              )}
            >
              {plan.popular && (
                <span className="absolute -top-2.5 left-5 rounded-full bg-primary px-3 py-0.5 text-[10px] font-bold text-primary-foreground">
                  MÁS POPULAR
                </span>
              )}
              <div className="mb-5">
                <h3 className="text-lg font-semibold text-foreground">{plan.name}</h3>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="stat-number text-4xl text-foreground">{plan.price}</span>
                  <span className="text-sm text-muted-foreground">{plan.period}</span>
                </div>
              </div>

              <div className="mb-5 flex items-center gap-2 rounded-lg bg-secondary/50 px-3 py-2">
                <Users className="h-3.5 w-3.5 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">
                  <span className="font-semibold text-foreground">{plan.members}</span> miembros activos
                </span>
              </div>

              <ul className="space-y-2.5">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2.5">
                    <Check className={cn("mt-0.5 h-3.5 w-3.5 shrink-0", plan.popular ? "text-primary" : "text-muted-foreground")} />
                    <span className="text-sm text-foreground/80">{feature}</span>
                  </li>
                ))}
              </ul>

              <button className={cn(
                "mt-6 w-full rounded-lg py-2.5 text-sm font-semibold transition-smooth",
                plan.popular
                  ? "bg-primary text-primary-foreground hover:opacity-90"
                  : "bg-secondary text-foreground hover:bg-secondary/80"
              )}>
                Editar Plan
              </button>
            </motion.div>
          ))}
        </div>

        {/* Freeze policies */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          className="rounded-xl border border-border/50 bg-card p-5"
        >
          <div className="flex items-center gap-2.5 mb-3">
            <Snowflake className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Políticas de Congelamiento</h3>
          </div>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
            {[
              { plan: "Básico", rule: "Sin congelamiento", active: 0 },
              { plan: "Premium", rule: "1 vez/año, máx 30 días", active: 8 },
              { plan: "VIP", rule: "Ilimitado, máx 60 días c/u", active: 3 },
            ].map((policy) => (
              <div key={policy.plan} className="rounded-lg bg-secondary/30 p-3">
                <span className="text-xs font-semibold text-foreground">{policy.plan}</span>
                <p className="mt-1 text-xs text-muted-foreground">{policy.rule}</p>
                <p className="mt-1.5 text-[10px] text-muted-foreground/60">{policy.active} congelamientos activos</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </Layout>
  );
};

export default Plans;
