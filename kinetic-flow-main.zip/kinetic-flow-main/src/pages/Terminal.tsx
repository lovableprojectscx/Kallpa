import { Layout } from "@/components/Layout";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { ScanLine, Check, X, Clock } from "lucide-react";

type ScanStatus = "idle" | "approved" | "denied";

const Terminal = () => {
  const [status, setStatus] = useState<ScanStatus>("idle");
  const [scannedMember, setScannedMember] = useState<{ name: string; plan: string; expires: string } | null>(null);

  const simulateScan = (type: "approved" | "denied") => {
    if (type === "approved") {
      setScannedMember({ name: "Roberto Silva", plan: "Premium", expires: "15 Mar 2026" });
    } else {
      setScannedMember({ name: "Patricia Vega", plan: "Básico", expires: "Vencido" });
    }
    setStatus(type);
    setTimeout(() => {
      setStatus("idle");
      setScannedMember(null);
    }, 4000);
  };

  return (
    <Layout>
      <div className="flex h-full flex-col items-center justify-center">
        {/* Ambient Status Glow */}
        <AnimatePresence>
          {status !== "idle" && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className={cn(
                "pointer-events-none fixed inset-0 z-50 rounded-xl border-4",
                status === "approved" ? "border-glow-green border-success/30" : "border-glow-red border-coral/30"
              )}
              style={{ filter: "blur(0px)" }}
            >
              <div className={cn(
                "absolute inset-0",
                status === "approved"
                  ? "bg-gradient-to-b from-success/5 to-transparent"
                  : "bg-gradient-to-b from-coral/5 to-transparent"
              )} />
            </motion.div>
          )}
        </AnimatePresence>

        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex w-full max-w-lg flex-col items-center gap-8"
        >
          <div className="text-center">
            <h1 className="font-display text-2xl text-foreground">Terminal de Acceso</h1>
            <p className="mt-1 text-sm text-muted-foreground">Escanee el código QR del miembro</p>
          </div>

          {/* QR Scanner Area */}
          <div className={cn(
            "relative flex h-72 w-72 items-center justify-center rounded-2xl border-2 border-dashed transition-smooth",
            status === "idle" && "border-border/50 bg-card/50",
            status === "approved" && "border-success/50 bg-success/5 animate-pulse-volt",
            status === "denied" && "border-coral/50 bg-coral/5 animate-pulse-coral"
          )}>
            <AnimatePresence mode="wait">
              {status === "idle" && (
                <motion.div
                  key="idle"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-col items-center gap-3"
                >
                  <ScanLine className="h-16 w-16 text-muted-foreground/30" />
                  <span className="text-xs text-muted-foreground/50">Esperando escaneo...</span>
                </motion.div>
              )}
              {status === "approved" && scannedMember && (
                <motion.div
                  key="approved"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-col items-center gap-3"
                >
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-success/20">
                    <Check className="h-8 w-8 text-success" />
                  </div>
                  <span className="font-display text-lg text-foreground">{scannedMember.name}</span>
                  <span className="text-xs text-muted-foreground">{scannedMember.plan} · Vence: {scannedMember.expires}</span>
                </motion.div>
              )}
              {status === "denied" && scannedMember && (
                <motion.div
                  key="denied"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-col items-center gap-3"
                >
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-coral/20">
                    <X className="h-8 w-8 text-coral" />
                  </div>
                  <span className="font-display text-lg text-foreground">{scannedMember.name}</span>
                  <span className="text-xs text-coral font-semibold">Membresía Vencida</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Demo Buttons */}
          <div className="flex gap-3">
            <button
              onClick={() => simulateScan("approved")}
              className="rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-smooth hover:opacity-90"
            >
              Simular Aprobado
            </button>
            <button
              onClick={() => simulateScan("denied")}
              className="rounded-lg bg-coral/10 px-5 py-2.5 text-sm font-semibold text-coral transition-smooth hover:bg-coral/20"
            >
              Simular Vencido
            </button>
          </div>

          {/* Recent scans */}
          <div className="w-full rounded-xl border border-border/50 bg-card">
            <div className="border-b border-border/30 px-5 py-3">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Últimos Accesos</h3>
            </div>
            {[
              { name: "Roberto Silva", time: "08:15", ok: true },
              { name: "Diana López", time: "08:12", ok: true },
              { name: "Patricia Vega", time: "08:08", ok: false },
            ].map((entry) => (
              <div key={entry.name} className="flex items-center justify-between border-b border-border/10 px-5 py-2.5 last:border-0">
                <div className="flex items-center gap-2.5">
                  <div className={cn(
                    "h-2 w-2 rounded-full",
                    entry.ok ? "bg-success" : "bg-coral"
                  )} />
                  <span className="text-sm text-foreground">{entry.name}</span>
                </div>
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  <span className="font-mono text-xs">{entry.time}</span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </Layout>
  );
};

export default Terminal;
